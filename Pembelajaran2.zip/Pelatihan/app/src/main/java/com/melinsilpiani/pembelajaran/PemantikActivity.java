package com.melinsilpiani.pembelajaran;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class PemantikActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pemantik);
        setTitle("Pertanyaan Pemantik");
    }
}