package com.melinsilpiani.pembelajaran;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ActivityTujuan extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tujuan);
        setTitle("Tujuan Pembelajaran");
    }
}