package com.melinsilpiani.pembelajaran;

import androidx.appcompat.app.AppCompatActivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btTujuan=(Button)  findViewById(R.id.bt_tujuan);

        btTujuan.setOnClickListener(new View.OnClickListener() {
        @Override
            public void onClick(View v){
            Intent i=new
                    Intent(MainActivity.this,ActivityTujuan.class);
            startActivity(i);
        }
        });
        Button btPemantik=(Button)  findViewById(R.id.bt_pemantik);

        btPemantik.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent i=new
                        Intent(MainActivity.this,PemantikActivity.class);
                startActivity(i);
            }
        });
        Button btPetaKonsep=(Button)  findViewById(R.id.bt_petakonsep);

        btPetaKonsep.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent i=new
                        Intent(MainActivity.this,ActivityPetaKonsep.class);
                startActivity(i);
            }
        });
        Button btMateri=(Button)  findViewById(R.id.bt_materi);

        btMateri.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent i=new
                        Intent(MainActivity.this,ActivityMateri.class);
                startActivity(i);
            }
        });
        Button btTentangAplikasi=(Button)  findViewById(R.id.bt_tentangaplikasi);

        btTentangAplikasi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent i=new
                        Intent(MainActivity.this,ActivityTentangAplikasi.class);
                startActivity(i);
            }
        });
    }
}